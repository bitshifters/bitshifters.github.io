void mouse_poll();

extern int mcount;
extern uint8_t mouse_portb;
extern int mouse_amx;
