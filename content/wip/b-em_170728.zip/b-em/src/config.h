void config_load();
void config_save();

extern int curmodel;
extern int selecttube;
