void main_init(int argc, char *argv[]);
void main_reset();
void main_restart();
void main_run();
void main_close();

void main_cleardrawit();
void main_setmouse();

