extern uint8_t compact_joystick_read();
