void uef_load(char *fn);
void uef_close();
void uef_poll();
void uef_findfilenames();

extern int uef_toneon;
