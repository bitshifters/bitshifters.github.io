void pal_init();
void pal_convert(BITMAP *inb, int x1, int y1, int x2, int y2, int yoff);
