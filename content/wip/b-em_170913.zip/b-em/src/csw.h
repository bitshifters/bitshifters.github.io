void csw_load(char *fn);
void csw_close();
void csw_poll();
void csw_findfilenames();

extern int csw_ena;
extern int csw_toneon;
