void n32016_init();
void n32016_reset();
void n32016_exec();
void n32016_close();
