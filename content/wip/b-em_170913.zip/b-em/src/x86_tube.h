void x86_init();
void x86_reset();
void x86_exec();
void x86_close();
