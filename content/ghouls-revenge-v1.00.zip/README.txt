Ghouls: Revenge
===============

Credits
=======

Original game code, almost entirely retained: David J Hoskins

Level editor and some additional game code: Tom Seddon

Level design and testing: Kieran Connell, Stew Badger, Dave Footitt,
VectorEyes, Tom Seddon

Title screen: Dethmunk

Instructions
============

For instructions, please see the README on GitHub:

https://github.com/tom-seddon/ghouls-revenge/blob/main/docs/ghouls-revenge.md

GitHub
======

Buildable code can be found on GitHub:

https://github.com/tom-seddon/ghouls-revenge

Version Info
============

V1.00
Build ID: 20241030-210319-6c5c267
